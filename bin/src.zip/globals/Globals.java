package globals;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Globals
{
	public static JTextArea terminalArea = new JTextArea(3,3);

}
